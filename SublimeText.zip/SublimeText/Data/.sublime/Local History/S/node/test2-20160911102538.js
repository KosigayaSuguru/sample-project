var hoge = new Hoge(){}

Hoge.prototype.aaaaa = function() {
    return 1000;
}

module.exports = hoge;